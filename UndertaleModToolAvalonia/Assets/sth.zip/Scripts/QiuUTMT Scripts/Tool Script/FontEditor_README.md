# UndertaleFontEditor
UndertaleModTool script, font editor GUI inspired by Lazy Shell

(can export and import to ZIP)

<img src = "https://i.imgur.com/Bfzlm2h.png/">
